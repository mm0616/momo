#include "ESP01_Wed.h"

// ==================== 构造函数 ====================
ESP01_Wed::ESP01_Wed(const char* ssid, const char* password, int serialBaud) 
    : _ssid(ssid), _password(password), _serialBaud(serialBaud), _server(80) {
    _buttonCount = 0;
    _sensorCount = 0;
    _lastSensorRead = 0;
}

// ==================== SensorData结构体方法 ====================
void ESP01_Wed::SensorData::update(String key, String value) {
    if (key == "water") water = value.toInt();
    else if (key == "temperature") temperature = value.toFloat();
    else if (key == "humidity") humidity = value.toFloat();
    else if (key == "light") light = value.toInt();
    else if (key == "ultrasonic") ultrasonic = value.toFloat();
    else if (key == "smoke") smoke = value.toInt();
    else if (key == "alcohol") alcohol = value.toInt();
    else if (key == "soil") soil = value.toInt();
    else if (key == "pot") pot = value.toInt();
}

// ==================== 公共方法 ====================

// 初始化库（与原始代码完全一致）
void ESP01_Wed::begin() {
    Serial.begin(_serialBaud);
    _setupWiFi();
    _setupServer();
}

// 主循环
void ESP01_Wed::loop() {
    _server.handleClient();
    
    // 定期读取传感器数据
    if (millis() - _lastSensorRead >= _sensorReadInterval) {
        _readSensorData();
        _lastSensorRead = millis();
    }
}

// 添加切换按钮
void ESP01_Wed::addToggleButton(String btnName, String onCommand, String offCommand) {
    if (_buttonCount < 15) {
        _buttons[_buttonCount].btnName = btnName;
        _buttons[_buttonCount].onCommand = onCommand;
        _buttons[_buttonCount].offCommand = offCommand;
        _buttons[_buttonCount].htmlId = "btn_" + String(_buttonCount);
        _buttonCount++;
    }
}

// 添加传感器显示
void ESP01_Wed::addSensor(String displayName, String jsonKey, String htmlId) {
    if (_sensorCount < 15) {
        _sensors[_sensorCount].displayName = displayName;
        _sensors[_sensorCount].jsonKey = jsonKey;
        _sensors[_sensorCount].htmlId = htmlId;
        _sensorCount++;
    }
}

// 手动更新传感器数据（字符串版本）
void ESP01_Wed::updateSensorData(String key, String value) {
    _sensorData.update(key, value);
}

// 手动更新传感器数据（浮点数版本）
void ESP01_Wed::updateSensorData(String key, float value) {
    updateSensorData(key, String(value, 1));
}

// 手动更新传感器数据（整数版本）
void ESP01_Wed::updateSensorData(String key, int value) {
    updateSensorData(key, String(value));
}

// 获取服务器IP地址
IPAddress ESP01_Wed::getIP() {
    return WiFi.localIP();
}

// 获取WiFi连接状态
bool ESP01_Wed::isConnected() {
    return WiFi.status() == WL_CONNECTED;
}

// ==================== 私有方法 ====================

// 设置WiFi连接（恢复为原始代码的简单等待方式）
void ESP01_Wed::_setupWiFi() {
    Serial.println("Connecting to WiFi");
    WiFi.begin(_ssid, _password);
    // Serial.print("Connecting to WiFi SSID: ");
    // Serial.print(_ssid);
    // Serial.print("   Pass: ");
    // Serial.println(_password);
    // 简单地等待直到连接成功，与原始代码一致
    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        delay(500);
    }
    delay(100);
    Serial.println("");
    Serial.println("WiFi connected");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
}

// 设置Web服务器
void ESP01_Wed::_setupServer() {
    _server.on("/", [this]() { _handleRoot(); });
    _server.on("/control", [this]() { _handleControl(); });
    _server.on("/read", [this]() { _handleReadSensors(); });
    
    _server.begin();
    Serial.println("HTTP server started");
}

// 读取传感器数据（通过串口）
void ESP01_Wed::_readSensorData() {
    Serial.println("SENSOR_READ");
    unsigned long startTime = millis();
    
    while (millis() - startTime < 500) {
        if (Serial.available() > 0) {
            String response = Serial.readStringUntil('\n');
            response.trim();
            
            // 解析传感器数据（与原始代码一致）
            if (response.startsWith("WATER:")) {
                updateSensorData("water", response.substring(6));
            }
            else if (response.startsWith("TEMP:")) {
                updateSensorData("temperature", response.substring(5));
            }
            else if (response.startsWith("HUM:")) {
                updateSensorData("humidity", response.substring(4));
            }
            else if (response.startsWith("LIGHT:")) {
                updateSensorData("light", response.substring(6));
            }
            else if (response.startsWith("ULTRA:")) {
                updateSensorData("ultrasonic", response.substring(6));
            }
            else if (response.startsWith("SMOKE:")) {
                updateSensorData("smoke", response.substring(6));
            }
            else if (response.startsWith("ALCOHOL:")) {
                updateSensorData("alcohol", response.substring(8));
            }
            else if (response.startsWith("SOIL:")) {
                updateSensorData("soil", response.substring(5));
            }
            else if (response.startsWith("POT:")) {
                updateSensorData("pot", response.substring(4));
            }
        }
        delay(10);
    }
}

// 发送命令并重试（恢复为原始代码：只要有非空响应即成功）
bool ESP01_Wed::_sendCommandWithRetry(String command) {
    for (int retry = 0; retry < _maxRetry; retry++) {
        // 发送指令
        Serial.println(command);
        
        // 等待响应
        unsigned long startTime = millis();
        while (millis() - startTime < _responseTimeout) {
            if (Serial.available() > 0) {
                String response = Serial.readStringUntil('\n');
                response.trim();
                
                // 如果收到任何有效响应（非空），就认为成功
                if (response.length() > 0) {
                    Serial.println("Received response: " + response);
                    return true;  // 收到响应，认为成功
                }
            }
            delay(10);
        }
        
        // 超时未收到响应，重试
        Serial.println("No response, retry " + String(retry + 1) + " for: " + command);
        delay(50);
    }
    
    Serial.println("Failed after " + String(_maxRetry) + " retries: " + command);
    return false;
}

// 生成网页（与原始代码完全一致，只保留必要的部分）
String ESP01_Wed::_generateWebpage() {
    String html = R"rawliteral(
<!DOCTYPE HTML>
<html>
<head>
<title>ESP8266 Control</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, sans-serif;
    text-align: center;
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f0f0f0;
}
.header {
    margin-bottom: 30px;
    color: #333;
}
.control-group {
    margin-bottom: 30px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 15px;
}
.toggle-btn {
    border: 2px solid #b0b0b0;
    color: #333;
    padding: 15px 25px;
    text-align: center;
    text-decoration: none;
    font-size: 16px;
    cursor: pointer;
    border-radius: 8px;
    min-width: 120px;
    transition: all 0.3s ease;
    background-color: #e0e0e0;
    box-sizing: border-box;
}
.toggle-btn.active {
    border-color: #66BB6A;
    background-color: #81C784;
    color: #222;
}
.toggle-btn:active {
    transform: scale(0.98);
    border-color: #999;
}
.toggle-btn.active:active {
    border-color: #4CAF50;
}
.status-message {
    margin: 10px 0;
    padding: 10px;
    border-radius: 5px;
    font-weight: bold;
}
.status-success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
.status-error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
.sensor-group {
    margin: 30px 0;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}
.sensor-value {
    font-size: 18px;
    color: #2196F3;
    margin: 10px 0;
    font-weight: bold;
    background-color: #fff;
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
</style>
</head>
<body>
<div class="header">
    <h1>ESP8266 IoT Control</h1>
    <div id="statusMessage" class="status-message"></div>
</div>
<div class="control-group">
)rawliteral";

    for (int i = 0; i < _buttonCount; i++) {
        html += "<button class=\"toggle-btn\" id=\"" + _buttons[i].htmlId + "\" ";
        html += "data-on-cmd=\"" + _buttons[i].onCommand + "\" ";
        html += "data-off-cmd=\"" + _buttons[i].offCommand + "\" ";
        html += "onclick=\"sendCommandWithRetry(this)\">";
        html += _buttons[i].btnName + "</button>";
    }

    html += R"rawliteral(
</div>
<div class="sensor-group">
)rawliteral";

    for (int i = 0; i < _sensorCount; i++) {
        html += "<div class=\"sensor-value\" id=\"" + _sensors[i].htmlId + "\">" + _sensors[i].displayName + ": ---</div>";
    }

    html += R"rawliteral(
</div>
<script>
const sensors = [
)rawliteral";

    for (int i = 0; i < _sensorCount; i++) {
        html += "{ jsonKey: '" + _sensors[i].jsonKey + "', htmlId: '" + _sensors[i].htmlId + "' }";
        if (i < _sensorCount - 1) html += ",";
    }

    html += R"rawliteral(
];

function sendCommandWithRetry(btn) {
    const onCmd = btn.getAttribute("data-on-cmd");
    const offCmd = btn.getAttribute("data-off-cmd");
    const isActive = btn.classList.contains("active");
    
    let command;
    if (isActive) {
        command = offCmd;
    } else {
        command = onCmd;
    }
    
    showStatus("Sending: " + command, "info");
    
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/control?cmd=" + encodeURIComponent(command), true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                var response = xhr.responseText;
                if (response.includes("SUCCESS")) {
                    // 切换按钮状态
                    if (isActive) {
                        btn.classList.remove("active");
                    } else {
                        btn.classList.add("active");
                    }
                    showStatus("Success: " + command, "success");
                } else {
                    showStatus("Failed: " + command, "error");
                }
            } else {
                showStatus("Network error", "error");
            }
        }
    };
    xhr.send();
}

function showStatus(message, type) {
    var statusDiv = document.getElementById("statusMessage");
    statusDiv.textContent = message;
    statusDiv.className = "status-message";
    
    if (type === "success") {
        statusDiv.classList.add("status-success");
    } else if (type === "error") {
        statusDiv.classList.add("status-error");
    }
    
    // 3秒后清除状态消息
    setTimeout(function() {
        if (statusDiv.textContent === message) {
            statusDiv.textContent = "";
            statusDiv.className = "status-message";
        }
    }, 3000);
}

function readSensors() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/read", true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                sensors.forEach(sensor => {
                    if (data[sensor.jsonKey] !== undefined) {
                        const label = document.getElementById(sensor.htmlId).innerText.split(":")[0];
                        document.getElementById(sensor.htmlId).innerHTML = label + ": " + data[sensor.jsonKey];
                    }
                });
            } catch(e) {
                console.error("解析传感器数据失败:", e);
            }
        }
    };
    xhr.send();
}

setInterval(readSensors, 1000);
window.onload = readSensors;
</script>
</body>
</html>
)rawliteral";

    return html;
}

// 处理根路径请求
void ESP01_Wed::_handleRoot() {
    _server.send(200, "text/html", _generateWebpage());
}

// 处理控制请求
void ESP01_Wed::_handleControl() {
    if (_server.hasArg("cmd")) {
        String command = _server.arg("cmd");
        bool success = _sendCommandWithRetry(command);
        if (success) {
            _server.send(200, "text/plain", "SUCCESS: Command executed");
        } else {
            _server.send(500, "text/plain", "ERROR: No response from UNO");
        }
    } else {
        _server.send(400, "text/plain", "Missing command");
    }
}

// 处理传感器数据读取请求
void ESP01_Wed::_handleReadSensors() {
    String jsonResponse = "{";
    
    for (int i = 0; i < _sensorCount; i++) {
        String jsonKey = _sensors[i].jsonKey;
        
        if (jsonKey == "water") jsonResponse += "\"water\":" + String(_sensorData.water);
        else if (jsonKey == "temperature") jsonResponse += "\"temperature\":" + String(_sensorData.temperature, 1);
        else if (jsonKey == "humidity") jsonResponse += "\"humidity\":" + String(_sensorData.humidity, 1);
        else if (jsonKey == "light") jsonResponse += "\"light\":" + String(_sensorData.light);
        else if (jsonKey == "ultrasonic") jsonResponse += "\"ultrasonic\":" + String(_sensorData.ultrasonic, 1);
        else if (jsonKey == "smoke") jsonResponse += "\"smoke\":" + String(_sensorData.smoke);
        else if (jsonKey == "alcohol") jsonResponse += "\"alcohol\":" + String(_sensorData.alcohol);
        else if (jsonKey == "soil") jsonResponse += "\"soil\":" + String(_sensorData.soil);
        else if (jsonKey == "pot") jsonResponse += "\"pot\":" + String(_sensorData.pot);
        
        if (i < _sensorCount - 1) jsonResponse += ",";
    }
    
    jsonResponse += "}";
    _server.send(200, "application/json", jsonResponse);
}