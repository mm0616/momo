#ifndef ESP01_WED_H
#define ESP01_WED_H

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#include <ArduinoJson.h>

class ESP01_Wed {
public:
    // 构造函数：传入WiFi SSID、密码和串口波特率（默认750）
    ESP01_Wed(const char* ssid, const char* password, int serialBaud = 750);
    
    // 初始化函数：必须在setup()中调用
    void begin();
    
    // 主循环函数：必须在loop()中调用
    void loop();
    
    // 添加切换按钮
    void addToggleButton(String btnName, String onCommand, String offCommand);
    
    // 添加传感器显示
    void addSensor(String displayName, String jsonKey, String htmlId);
    
    // 手动更新传感器数据（可选）
    void updateSensorData(String key, String value);
    void updateSensorData(String key, float value);
    void updateSensorData(String key, int value);
    
    // 获取服务器IP地址
    IPAddress getIP();
    
    // 获取WiFi连接状态
    bool isConnected();

private:
    // 结构体定义
    struct ToggleButton {
        String btnName;    // 按钮显示文本
        String onCommand;  // 开启命令
        String offCommand; // 关闭命令
        String htmlId;     // HTML唯一ID
    };
    
    struct SensorItem {
        String displayName; // 传感器显示名称
        String jsonKey;     // JSON字段名
        String htmlId;      // HTML元素ID
    };
    
    struct SensorData {
        int water = 0;
        float temperature = 0;
        float humidity = 0;
        int light = 0;
        float ultrasonic = 0;
        int smoke = 0;
        int alcohol = 0;
        int soil = 0;
        int pot = 0;
        
        void update(String key, String value);
    };
    
    // WiFi配置
    const char* _ssid;
    const char* _password;
    int _serialBaud;
    
    // 服务器对象
    ESP8266WebServer _server;
    
    // 数据存储
    ToggleButton _buttons[15]; // 最多15个按钮
    SensorItem _sensors[15];   // 最多15个传感器
    int _buttonCount;
    int _sensorCount;
    
    // 传感器数据
    SensorData _sensorData;
    
    // 时间控制
    unsigned long _lastSensorRead;
    const unsigned long _sensorReadInterval = 1000; // 1秒读取间隔
    
    // 串口通信参数（与原始代码一致）
    const int _maxRetry = 3;
    const int _responseTimeout = 500; // 0.5秒
    
    // 私有方法
    void _setupWiFi();
    void _setupServer();
    void _readSensorData();
    bool _sendCommandWithRetry(String command);
    String _generateWebpage();
    void _handleControl();
    void _handleReadSensors();
    void _handleRoot();
};

#endif // ESP01_WED_H